<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Save extends CI_Model {


	
	public function save_header()
	{
		
		$data =array();
		$data['header']=$this->input->post('header',true);
		$data['header_content1']=$this->input->post('header_content1',true);
		$data['header_content2']=$this->input->post('header_content2',true);
		if(isset($_FILES['logo']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('logo')){
				$uploadlogo=$this->upload->data();
				$data['logo']=$uploadlogo['file_name'];
			}
		}
		if(isset($_FILES['hb']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('hb')){
				$uploadhb=$this->upload->data();
				$data['hb']=$uploadhb['file_name'];
			}
		}
		
		
		$this->db->insert('header',$data);
			
		
	}

    public function save_post()
	{
		
		$data =array();
		$data['title']=$this->input->post('title',true);
		$data['date']=$this->input->post('date',true);
		$data['post']=$this->input->post('post',true);
		$data['post_by']=$this->input->post('post_by',true);
		if(isset($_FILES['image']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('image')){
				$uploadimage=$this->upload->data();
				$data['image']=$uploadimage['file_name'];
			}
		}
		$this->db->insert('post',$data);
			
		
	}


public function save_author()
{
	
	$data =array();
	$data['username']=$this->input->post('username',true);
	$data['name']=$this->input->post('name',true);
	$data['email']=$this->input->post('email',true);
	$data['password']= md5($this->input->post('password',true));
	$data['status']="0";
	$this->db->insert('author',$data);
		
	
}

public function save_author_fe()
{
	
	$data =array();
	$data['username']=$this->input->post('username',true);
	$data['email']=$this->input->post('email',true);
	$data['password']= md5($this->input->post('password',true));
	$data['status']="0";
	$this->db->insert('author',$data);
		
	
}


public function approve_author($id)
{
	$data['status'] ='1';
	
	

	
	$this->db->where(array('id'=>$id));
	$this->db->update('author', $data);

}
//**save author end */
	public function save_aboutpage()
	{
		
		$data =array();
		$data['title']=$this->input->post('title',true);
		
		$data['hb']="0";
		
		$this->db->insert('aboutpage',$data);
			
		
	}


	public function save_addpost()
	{
		
		$data =array();
		$data['title']=$this->input->post('title',true);
		$data['date']=$this->input->post('date',true);
		if(isset($_FILES['image']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('image')){
				$uploadimage=$this->upload->data();
				$data['image']=$uploadimage['file_name'];
			}
		}
		$data['post']=$this->input->post('post',true);
		$data['post_by']=$this->input->post('post_by',true);
		$this->db->insert('post',$data);
			
		
	}


	//**save add author */
	public function save_addauthor()
	{
		
		$data =array();
		$data['username']=$this->input->post('username',true);
		$data['name']=$this->input->post('name',true);
		$data['email']=$this->input->post('email',true);
		$data['password']=$this->input->post('password',true);
	    $data['status']="0";
		$this->db->insert('author',$data);
			
		
	}
	public function save_addpost_ah()
	{
		
		$data =array();
		$data['title']=$this->input->post('title',true);
		$data['date']=$this->input->post('date',true);
		if(isset($_FILES['image']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('image')){
				$uploadimage=$this->upload->data();
				$data['image']=$uploadimage['file_name'];
			}
		}
		$data['post']=$this->input->post('post',true);
		$data['post_by']=$this->input->post('post_by',true);
		$this->db->insert('post',$data);
			
		
	}
	//** */


	public function updatehdr($id)
	{
		
		
		$data['header']=$this->input->post('header',true);
		$data['header_content1']=$this->input->post('header_content1',true);
		$data['header_content2']=$this->input->post('header_content2',true);
		if(isset($_FILES['logo']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('logo')){
				$uploadlogo=$this->upload->data();
				$data['logo']=$uploadlogo['file_name'];
			}
		}
		if(isset($_FILES['hb']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('hb')){
				$uploadhb=$this->upload->data();
				$data['hb']=$uploadhb['file_name'];
			}
		}
		
		
		$this->db->where(array('id'=>$id));
		$this->db->update('header',$data);
			
		
	}
	public function deletehdr($id)
	{
		
		
		$this->db->where(array('id'=>$id));
		$this->db->delete('header');
			
		
	}

	public function updatepost($id)
	{
		
		
		$data['title']=$this->input->post('title',true);
		$data['date']=$this->input->post('date',true);
	
		$data['post']=$this->input->post('post',true);
		$data['post_by']=$this->input->post('post_by',true);

		if(isset($_FILES['image']['name'])){
			$this->load->library('upload');
			$config['upload_path']          =APPPATH.'../asset/uploads/';
			$config['allowed_types']        ='gif|jpg|png|jpeg';
			$config['file_name']           =date('YmdHms').'_'.rand(1,9999999);
			$this->upload->initialize($config);
			if($this->upload->do_upload('image')){
				$uploadimage=$this->upload->data();
				$data['image']=$uploadimage['file_name'];
			}
		}
		$data['like_post']="0";
		$this->db->where(array('id'=>$id));
		$this->db->update('post',$data);
			
		
	}

	
	public function updateauthor($id)
	{
		
		
		$data['username']=$this->input->post('username',true);
		$data['name']=$this->input->post('name',true);
		$data['email']=$this->input->post('email',true);
		$data['password']=$this->input->post('password',true);
		$data['status']="0";
		$this->db->where(array('id'=>$id));
		$this->db->update('author',$data);
			
		
	}
    
	

	public function deletepost($id)
	{
		
		
		$this->db->where(array('id'=>$id));
		$this->db->delete('post');
			
		
	}
	
	public function deleteauthor($id)
	{
		
		
		$this->db->where(array('id'=>$id));
		$this->db->delete('author');
			
		
	}

	



	

    
}
