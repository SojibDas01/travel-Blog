<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/asset/dist/css/jquery.animatedheadline.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/asset/css/bootstrap.min.css">
    <link rel="stylesheet"  href="<?php echo base_url();?>/asset/js/bootstrap.min.js">
    <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/fontawesome/css/all.min.css"/>
    <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/slick.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/slick-theme.css">
    

    
    <title>TRAVEL BLOG</title>
</head>
<body>
<?php
                foreach($fetchhdr as $hdr){
                }
                ?>
       <!--Header  section-->
   <header class="Fix-margin" style=" background: linear-gradient(rgba(0,0,0,.65),rgba(0, 0, 0, 0.55)),
    url(<?php echo base_url().'asset/uploads/'.$hdr->hb;?> )center center no-repeat;">
   
   
       <!--HEADER TOP --- *logo & NAVEBAR*--->
       <div class="header-top" style="background-color: #a6bedb;">
       
           <div class="logo">
           <img src="<?php echo base_url().'asset/uploads/'.$hdr->logo;?>"  alt="">
            
           </div>
           <!--HEADER NAVEBAR SECTION-->
           <div class="header-navbar">
           <ul>
           <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="blog">Home</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="about">about</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="allblog">All Post</a></button></li>
 
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="user">singup</a></button></li>
          </ul>
              
           </div>
           <!--HEADER NAVEBAR SECTION CLOSE-->
      
         
       </div>
 <!--HEADER TITEL-->
       <div class="header-titel">
      <div class="box1" style="">
      <h3><?php echo $hdr->header;?> </h3> 
          <h4><?php echo $hdr->header_content1?></h4>
           <p><?php echo $hdr->header_content2?></p>
      </div>
          
       
   
    </div>
    <!--HEADER TITEL Close-->

        
   </header>
  

   <!--HEADER SECTION CLOSE-->
   <!--About Section---->
        <!--Post SEction-->  
 
        
   <div class="post">

       <div class="post-area">
       <div class="newpost">
       
       </div>
       <p  style="color:rgb(110, 12, 58);text-align:center ;font-size:20px;margin-top:10px">Travle Posts</p>
     

    </div>
    <div class="container">
      <div class="row">
      <?php
                foreach($allblog_recenrpost as $rpost){
                
                ?>
        <div class="col-sm-6">
          <div class="card bg-dark text-black">
            <img style=" height:300px;"  src="<?php echo base_url().'asset/uploads/'.$rpost->image;?>" class="card-img" id="imght"alt="...">
            <div class="card-img-overlay">
              <h5 class="card-title" style="color:white;"><?php echo  substr($rpost->title,0,50);?></h5>
              <h6 style="color:white;"><?php echo  substr($rpost->date,0,50);?>| <?php echo  substr($rpost->post_by,0,50);?><span></h6>
              <p class="card-text" style="color:white;"><?php echo  substr($rpost->post,0,50);?></p>
              <p class="card-text">
              <a style=" margin-bottom: 2px;" class="btn btn-primary" href="<?php echo site_url('blog/viewsinglepost/'.$rpost->id)?>">read more</a>
              </p>
              
            </div>
          </div>
        <br>
        </div>
        
        
        <?php
         }
            ?>
     
       
      </div>
     
    </div>
  
     
 
     </div>

 

        </div>
 
 


<div  style=" height:180px;background:  rgb(37, 4, 7);" class="fotter" >
  
  <div class="rightfotter">
    <br>
 <img  src="asset/images/Untitled.jpg" alt="">
  </div>
 
  <div class="midelfotter">
    <br>
    <p class="mfooter"><h6 style="color:rgb(189, 172, 172)">this is a travle blog.</h6></p>

  </div>


  <div class="leftfooter">
    <br>
    <a  href="https://www.facebook.com/"><i  class="fab fa-facebook icon"></i></a> &nbsp
    <a  href="https://www.instagram.com/"><i class="fab fa-instagram-square icon"></i></a>
     <br>
     <p style="color:white;">about my tream :

     </p>  
      
 
        </p>
   
  </div>
   <!--footreRight side end-->
</div>


</body>
</html>





