<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700' rel='stylesheet' type='text/css'>

    
    <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/singlepost.css">
   
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/asset/css/bootstrap.min.css">
    <link rel="stylesheet"  href="<?php echo base_url();?>/asset/js/bootstrap.min.js">
    <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/fontawesome/css/all.min.css" />
    
    <title>post</title>
</head>
<body>
             <!--Header  section-->
   <header class="Fix-margin">
    <!--HEADER TOP --- *logo & NAVEBAR*--->
    <div class="header-top">
        <div class="logo">
         <img src="asset/images/logo.png" alt="">
        </div>
             <!--HEADER NAVEBAR SECTION-->
             <div class="header-navbar">
              <ul>
              <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="<?php echo base_url();?>blog">Home</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="<?php echo base_url();?>about">about</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="<?php echo base_url();?>allblog">ALL Blog</a></button></li>
 
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="<?php echo base_url();?>singup">singup</a></button></li>
             </ul>
                 
              </div>
              <!--HEADER NAVEBAR SECTION CLOSE-->
           <button class="humberger" onclick="toggle()"><!--.humberger-->
            <i class="fas fa-bars"></i>
          </button>
          <nav id="m-nav" class="mobial-nav">
           
            <button id="close" class="close" onclick="toggle()">
              <i class="fas fa-times"></i>
            </button>
            <ul>
            <li><a id="btn" href="blog">Home</a></li>
            <li><a id="btn" href="about">About</a></li>
            
            <li><a id="btn" href="allblog">Blog</a></li>
            <li><a id="btn" href="login">Register</a></li>
            </ul><!--.main-nav ul li-->
            
    
          </nav>
        
    </div>
<!--HEADER TITEL-->
<br><br><br>
<div class="container" style="margin-left:300px">
     <div class="row">
   
     <div class="col-sm-6"  >
          <div class="card bg-dark text-black" style=" height:550px width:550px">
            <img style=" height:300px;"  src="<?php echo base_url().'asset/uploads/'.$viewsinglepost->image;?>" class="card-img" id="imght"alt="...">
            <div class="card-img-overlay">
              <h5 class="card-title" style="color:white;"><?php echo $viewsinglepost->title;?></h5>
              <h6 style="color:white;"><?php echo $viewsinglepost->date;?>| <?php echo $viewsinglepost->post_by;?><span></h6>
              <p class="card-text" style="color:white;"><?php echo $viewsinglepost->post;?></p>
            
              
            </div>
          </div>

        </div>



     
</header>
       
            

</body>
</html>