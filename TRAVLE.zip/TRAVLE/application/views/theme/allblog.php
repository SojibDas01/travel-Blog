<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700' rel='stylesheet' type='text/css'>

    
    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/blog.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>asset/css/bootstrap.min.css">
    <link rel="stylesheet"  href="<?php echo base_url();?>asset/js/bootstrap.min.js">
    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/fontawesome/css/all.min.css" />
   
    

    
    <title>TRAVEL BLOG</title>
</head>
<body>
       <!--Header  section-->
       <header class="Fix-margin" id="aboutheader" >
        <!--HEADER TOP --- *logo & NAVEBAR*--->
        <div class="header-top" >
            <div class="logo">
             <img src="asset/images/Untitled.jpg" alt="">
            </div>
            <!--HEADER NAVEBAR SECTION-->
            <div class="header-navbar">
            <ul>
            <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="blog">Home</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="about">about</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="allblog">All post</a></button></li>
 
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="user">singup</a></button></li>
           </ul>
               
            </div>
            <!--HEADER NAVEBAR SECTION CLOSE-->
            <button class="humberger" onclick="toggle()"><!--.humberger-->
             <i class="fas fa-bars"></i>
           </button>
           <nav id="m-nav" class="mobial-nav">
            
             <button id="close" class="close" onclick="toggle()">
               <i class="fas fa-times"></i>
             </button>
             <ul>
             <li><a id="btn" href="blog">Home</a></li>
            <li><a id="btn" href="about">About</a></li>
            
            <li><a id="btn" href="allblog">Blog</a></li>
            <li><a id="btn" href="login">Register</a></li>
             </ul><!--.main-nav ul li-->
             
     
           </nav>
            
        </div>
  <!--HEADER TITEL-->
        <div class="header-titel">
      
         <h3>TRAVEL BLOG</h3>
  <p>This is TRAVEL Blog</p>
         </h1>
     </section>
     </div>
     <!--HEADER TITEL Close-->
         
         
    </header>
  

   <!--HEADER SECTION CLOSE-->
   <!--About Section---->
        <!--Post SEction-->  
 
        
        <div class="post" style="background: rgb(73, 73, 71);;">
               <div id="p-titele">
                 <h3  style="color:white;text-align:center;">POST</h3>
                </div>
           
       
        
      

                <div class="container">
      <div class="row">
      <?php
                foreach($allblog as $fatchapost){
             
                  ?>
        <div class="col-sm-6">
          <div class="card bg-dark text-black">
            <img style=" height:300px;"  src="<?php echo base_url().'asset/uploads/'.$fatchapost->image;?>" class="card-img" id="imght"alt="...">
            <div class="card-img-overlay">
              <h5 class="card-title" style="color:white;"><?php echo  substr($fatchapost->title,0,50);?></h5>
              <h6 style="color:white;"><?php echo  substr($fatchapost->date,0,50);?>| <?php echo  substr($fatchapost->post_by,0,50);?><span></h6>
              <p class="card-text" style="color:white;"><?php echo  substr($fatchapost->post,0,50);?></p>
              <p class="card-text">
              <a style=" margin-bottom: 2px;" class="btn btn-primary" href="<?php echo site_url('blog/viewsinglepost/'.$fatchapost->id)?>">read more</a>
              </p>
              
            </div>
          </div>
        <br>
        </div>
        
        
        <?php
         }
            ?>
     
       
      </div>
     
    </div>
     <!--Git Off-->
     
 
        </div>



        </dv>

</body>
</html>