<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700' rel='stylesheet' type='text/css'>

    
    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/about.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>asset/css/bootstrap.min.css">
    <link rel="stylesheet"  href="<?php echo base_url();?>asset/js/bootstrap.min.js">
    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/fontawesome/css/all.min.css" />

    <title>About us</title>
</head>
<body>
    <header class="Fix-margin">
        <!--HEADER TOP --- *logo & NAVEBAR*--->
        <div class="header-top">
            <div class="logo">
             <p class="logo_titel">TRAVEL Blog</p>
            </div>
            <!--HEADER NAVEBAR SECTION-->
            <div class="header-navbar">
            <ul>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="blog">Home</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="about">about</a></button></li>
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="allblog">ALL Blog</a></button></li>
 
             <li><button type="button" class="btn btn-outline-secondary"><a id="btn" href="singup">Reg/singup</a></button></li>
             
           </ul>
               
            </div>
            <!--HEADER NAVEBAR SECTION CLOSE-->
            <button class="humberger" onclick="toggle()"><!--.humberger-->
             <i class="fas fa-bars"></i>
           </button>
           <nav id="m-nav" class="mobial-nav">
            
             <button id="close" class="close" onclick="toggle()">
               <i class="fas fa-times"></i>
             </button>
             <ul>
               <li><a id="btn" href="index.html">Home</a></li>
               <li><a id="btn" href="About.html">About</a></li>
               
              
              
             </ul><!--.main-nav ul li-->
             
     
           </nav>
            
        </div>
  <!--HEADER TITEL-->
        <div class="header-titel">
      
     <h2>About Blog</h2>
         <h4>here every new place or beautiful place infornation can be people find</h4>
         

     </div>
     <!--HEADER TITEL Close-->
         
         
    </header>
   
<!--
  Footer Section
-->
<div class="fotter">
  <!--footre left side-->
  <div class="rightfotter">
 <h1>Travel blog</h1>
  </div>
  <!--Left Footer End-->
   <!--footre middel  side-->
  <div class="midelfotter">
    <p class="mfooter">this is travel blog</p>

  </div>
 <!--footre right side-->

  <div class="leftfooter">
    <a  href="https://www.facebook.com/">facebook</a>
    <a  href="https://www.instagram.com/">instagram</i></a>
       
      
 
        </p>
   
  </div>
   <!--footreRight side end-->
</div>

</body>
</html>