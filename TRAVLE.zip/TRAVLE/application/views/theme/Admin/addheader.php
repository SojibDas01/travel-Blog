<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="asset/css/css/header.css">
  <link rel="stylesheet"  href="asset/js/bootstrap.min.js">
    <link rel="stylesheet" type="text/css" href="asset/css/bootstrap.min.css">
  <link rel="stylesheet" href="asset/css/fontawesome/css/all.min.css" />
    <title>Admin</title>
</head>
<body>
    <header>
        <div class="header-top">
         <h1>Welcome To Admin panel</h1>
        </div>
        <div class="manu">
            <div class="logo"><img src="asset/images/logo.png" alt=""></div>
            <div class="navbar">
            <ul>
                      
                      <li><a id="btn" href="admin"><i class="fas fa-book-reader"></i> Header</a></li>
                      <li><a id="btn" href="post"><i class="fas fa-portrait"></i> Post</a></li>
                        <li><a id="btn" href="author"><i class="fas fa-at"></i> Author</a></li>
                      
                        <li><a id="btn" href="<?php echo site_url('Admin/logout');?>"><i class="fas fa-sign-out-alt"></i> <span>SignOut</span> </a></li>
                        </ul>
                </div>
             
        </div>
        <div class="box">
        <form action="<?php base_url();?>savehdr" method="post" enctype="multipart/form-data">
                <div class="row">
                  <label>Header</label>
                  <input
                    type="text"
                    placeholder="Header"
                    id="header"
                    name="header"
                  />
                </div>
                <div class="row">
                  <label>Header Content1</label>
                  <input
                    type="text"
                    placeholder="Header Content"
                    id="header_content1"
                    name="header_content1"
                  />
                </div>
                <div class="row">
                  <label>Header Content2</label>
                  <input
                    type="text"
                    placeholder=" Header Content"
                    id="header_content2"
                    name="header_content2"
                  />
                </div>
                <div class="row">
                  <label>Logo</label>
                  <input type="file" id="logo" name="logo" accept="image/*" />
                  <label>Background</label>
                  <input type="file" id="hb" name="hb" accept="image/*" />
                
                </div>
                <div class="Submit-btn">
                 <input type="submit"  Value="Save" id="send" name="send">
                 <input type="reset"  Value="Clear" id="clear" name="clear">
               </div>
              </form>
           
        </div>
    </header>


        </div>
    </div>
</body>
</html>