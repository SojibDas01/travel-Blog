<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/css/header.css">
  <link rel="stylesheet"  href="<?php echo base_url();?>/asset/js/bootstrap.min.js">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/asset/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/fontawesome/css/all.min.css" />
  <title>Admin</title>
</head>
<body>
  <header>
      <div class="header-top">
       <h1> Author</h1>
      </div>
      <div class="manu">
          <br><br>
          <div class="navbar">
          <ul>
                      
                     <li><a id="btn" href="admin"><i class="fas fa-book-reader"></i> Header</a></li>
                      <li><a id="btn" href="post"><i class="fas fa-portrait"></i> Post</a></li>
                        <li><a id="btn" href="author"><i class="fas fa-at"></i> Author</a></li>
                      
                        <li><a id="btn" href="<?php echo site_url('Admin/logout');?>"><i class="fas fa-sign-out-alt"></i> <span>SingOut</span> </a></li>
                        </ul>
                </div>
              
           
      </div>
        <div class="box">
        <a class="addbtn" href="<?php echo base_url()?>addauthor">ADD NEW Author</a>
        <table class="table " style="color:white;">
                <thead>
                  <tr>
                    <th scope="col">Id</th>
                    <th scope="col">UserName</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">password</th>
                    <th scope="col">status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                foreach($fetchauthor as $author){
                  ?>
                  <tr class="">
                    <th scope="row"><?php echo $author->id;?></th>
                    
                    <td><?php echo  substr($author->username,0,10);?>..</td>
                    <td><?php echo  substr($author->name,0,10);?>..</td>
                    <td><?php echo  substr($author->email,0,10);?>..</td>
                    <td><?php echo  substr($author->password,0,10);?>..</td>
                    <td><?php echo $author->status;?></td>
                    <td>

                    <a class="btn btn-warning" href="<?php echo site_url('admin/editauthor/'.$author->id)?>">eidt</a>
                        <a class="btn btn-warning" href="<?php echo site_url('admin/deleteauthor/'.$author->id)?>">delete</a>
                        <a class="btn btn-warning"  href="<?php echo site_url('admin/viewauthor/'.$author->id)?>">view</a>
                       
         <?php 
         $sts = $author->status;
         if($sts<=0){
        
       ?>
       <a class="btn btn-warning" href="<?php echo site_url('admin/approveauthor/'.$author->id)?>" role="button">Pending</a></td>
     <?php      
         }
         ?>
     </tr>
     <?php
   }
   ?>
                </tbody>
              </table>
            
              <?php echo $this->pagination->create_links();?>
        </div>
    </header>


        </div>
    </div>
</body>
</html>