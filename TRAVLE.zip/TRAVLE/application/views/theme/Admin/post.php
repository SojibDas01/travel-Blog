<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/css/header.css">
  <link rel="stylesheet"  href="<?php echo base_url();?>/asset/js/bootstrap.min.js">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/asset/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/asset/css/fontawesome/css/all.min.css" />
  <title>Admin post</title>
</head>
<body>
  <header>
      <div class="header-top">
       <h1 >Admin Post</h1>
      </div>
      <div class="manu">

          <div class="navbar">
          <ul>
                      
                     <br>
                
                      <li><a id="btn" href="admin"><i class="fas fa-book-reader"></i> Header</a></li>
                      <li><a id="btn" href="post"><i class="fas fa-portrait"></i> Post</a></li>
                        <li><a id="btn" href="author"><i class="fas fa-at"></i> Author</a></li>
                        
                       
                      
                      
                        <li><a id="btn" href="<?php echo site_url('Admin/logout');?>"><i class="fas fa-sign-out-alt"></i> <span>SingOut</span> </a></li>
                        </ul>
                </div>
              
           
      </div>
        <div class="box">
        <a class="addbtn" href="<?php echo base_url()?>addpost">ADD NEW</a>
        <table class="table " style="color:white;">
                <thead>
                  <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Title</th>
                    <th scope="col">picture</th>
                    <th scope="col">post</th>
                    <th scope="col">date</th>
                    <th scope="col">post by</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                foreach($fetchpost as $post){
                  ?>
                  <tr class="">
                    <th scope="row"><?php echo $post->id;?></th>
                    <td><?php echo  substr($post->title,0,20);?>..</td>
                    <td><img width="50px" src="<?php echo base_url().'asset/uploads/'.$post->image;?>"></td>
                    <td><?php echo  substr($post->post,0,20);?>..</td>
                    <td><?php echo $post->date;?></td>
                    <td><?php echo $post->post_by;?></td>
                    <td>

                    <a class="btn btn-warning" href="<?php echo site_url('admin/editpost/'.$post->id)?>">eidt</a>
                        <a class="btn btn-warning" href="<?php echo site_url('admin/deletepost/'.$post->id)?>">delete</a>
                        <a class="btn btn-warning"  href="<?php echo site_url('admin/viewpost/'.$post->id)?>">view</a>

                        
                     </td>
                  </tr>
          
                  <?php
          }
          ?>
                </tbody>
              </table>
            
              <?php echo $this->pagination->create_links();?>
        </div>
    </header>


        </div>
    </div>
</body>
</html>